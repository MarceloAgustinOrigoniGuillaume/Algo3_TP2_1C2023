# /bin/bash
set -e

mvn clean javafx:run