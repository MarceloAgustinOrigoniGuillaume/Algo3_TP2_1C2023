package edu.fiuba.algo3.controladores;

public class Controlador {
}
