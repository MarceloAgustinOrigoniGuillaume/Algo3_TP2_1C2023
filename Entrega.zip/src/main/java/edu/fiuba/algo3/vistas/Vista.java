package edu.fiuba.algo3.vistas;


import javafx.scene.Parent;


public interface Vista{
	Parent obtener();
}