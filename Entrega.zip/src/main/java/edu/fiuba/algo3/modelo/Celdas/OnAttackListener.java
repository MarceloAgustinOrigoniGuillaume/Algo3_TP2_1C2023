package edu.fiuba.algo3.modelo.Celdas;

import edu.fiuba.algo3.modelo.descriptors.AttackDescriptor;

public interface OnAttackListener{
	void onAttack(AttackDescriptor ataque);
}