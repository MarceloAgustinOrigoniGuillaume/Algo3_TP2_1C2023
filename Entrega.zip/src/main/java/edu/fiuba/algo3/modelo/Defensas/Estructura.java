package edu.fiuba.algo3.modelo.Defensas;

public interface Estructura{
    int costo();
}
