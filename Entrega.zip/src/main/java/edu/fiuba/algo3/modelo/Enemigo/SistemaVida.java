package edu.fiuba.algo3.modelo.Enemigo;

public interface SistemaVida{
	void recibirAtaque(int atk);
	boolean estaMuerto();
}