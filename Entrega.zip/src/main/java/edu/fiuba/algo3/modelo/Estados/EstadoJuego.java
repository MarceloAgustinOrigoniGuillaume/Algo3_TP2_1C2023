package edu.fiuba.algo3.modelo.Estados;

public interface EstadoJuego {
    void ejecutarEstado() throws Exception;
}
