package edu.fiuba.algo3.modelo.descriptors;

public class AttackDescriptor{

    private String tipo;
    
    public AttackDescriptor(String tipo){
        this.tipo = tipo;
    }

    public String tipo(){
        return tipo;
    }
}

