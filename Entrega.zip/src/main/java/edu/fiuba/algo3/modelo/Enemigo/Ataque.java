package edu.fiuba.algo3.modelo.Enemigo;

public interface Ataque{

	//Pre: -
	//Post: Este ataque es para saber si hay una suficiente cantidad de daño para que el jugador muera.
	int ataqueMaximo();
}