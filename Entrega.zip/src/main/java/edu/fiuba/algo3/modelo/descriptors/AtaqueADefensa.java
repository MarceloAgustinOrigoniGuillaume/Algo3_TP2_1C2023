package edu.fiuba.algo3.modelo.descriptors;

public class AtaqueADefensa extends AttackDescriptor{
    
    public AtaqueADefensa(){
        super("DestruccionTorre.wav");
    }
}

